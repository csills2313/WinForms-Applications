﻿Namespace AllCars
    'Car SuperClass
    Class Car
        Implements IDisposable
        'Public and Private members
        Public Color As String
        Public CarName As String
        Private intSpeed As Integer
        Private intNumberOfDoors As Integer
        Private intHorsePower As Integer
        'Constructor
        Sub New()
            Color = "Red"
            intSpeed = 0
            intNumberOfDoors = 5
        End Sub
        'Gets speed
        Public ReadOnly Property Speed() As Integer
            Get
                Return intSpeed
            End Get
        End Property
        'Gets And Sets HorsePower
        Public Property HorsePower() As Integer
            Get
                Return intHorsePower
            End Get
            Set(ByVal value As Integer)
                intHorsePower = value
            End Set
        End Property
        'Accelerates The Car
        Public Sub Accelerate(ByVal accelerateBy As Integer)
            intSpeed += accelerateBy
        End Sub
        'Overwrite ToString
        Public Overrides Function ToString() As String
            Return "Car Name: " & CarName & Environment.NewLine & "Car Color: " & Color & Environment.NewLine & "Number of Doors: " & NumberOfDoors & Environment.NewLine & "Car Speed: " & intSpeed
        End Function
        'Gets and Sets number of Doors
        Public Property NumberOfDoors() As Integer
            Get
                Return intNumberOfDoors
            End Get
            Set(ByVal value As Integer)
                If value >= 2 And value <= 5 Then
                    intNumberOfDoors = value
                Else
                    MessageBox.Show("The number of doors you have entered is not valid.")
                End If
            End Set
        End Property
        'Is the car moving?
        Public Function isMoving() As Boolean
            If Speed = 0 Then
                Return False
            Else
                Return True
            End If
        End Function

#Region "IDisposable Support"
        Private disposedValue As Boolean ' To detect redundant calls

        ' IDisposable
        Protected Overridable Sub Dispose(ByVal disposing As Boolean)
            If Not Me.disposedValue Then
                If disposing Then
                    ' TODO: dispose managed state (managed objects).
                End If

                ' TODO: free unmanaged resources (unmanaged objects) and override Finalize() below.
                ' TODO: set large fields to null.
            End If
            Me.disposedValue = True
        End Sub

        ' TODO: override Finalize() only if Dispose(ByVal disposing As Boolean) above has code to free unmanaged resources.
        'Protected Overrides Sub Finalize()
        '    ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
        '    Dispose(False)
        '    MyBase.Finalize()
        'End Sub

        ' This code added by Visual Basic to correctly implement the disposable pattern.
        Public Sub Dispose() Implements IDisposable.Dispose
            ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
            Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub
#End Region

    End Class

    'SportsCar Class
    Class SportsCar
        Inherits Car
        Public weight As Integer
        'Constructor
        Sub New()
            Color = "Red"
            NumberOfDoors = 2
            weight = 1000
        End Sub
        'Show information
        Public Function getSportsInfo() As String
            Return "Car Name: " & CarName & Environment.NewLine & "Car Color: " & Color & Environment.NewLine & "Number of Doors: " & NumberOfDoors & Environment.NewLine & "Car Speed: " & Speed & Environment.NewLine & "HorsePower: " & HorsePower & Environment.NewLine & "Weight: " & weight
        End Function
        'Get Power To Weight Ratio
        Public Function getPowerToWeightRatio() As Double
            Return CType(HorsePower, Double) / CType(weight, Double)
        End Function
    End Class

    'Truck Class
    Class TruckCar
        Inherits Car
        Private truckBedLength As bedLength
        Private truckCabLength As cabLength
        'Gets and Sets theBedLength
        Public Property theBedLength() As bedLength
            Get
                Return truckBedLength
            End Get
            Set(ByVal value As bedLength)
                If value >= 0 And value <= 2 Then
                    truckBedLength = value
                End If
            End Set
        End Property
        'Gets and Sets truckCabLength
        Public Property theCabLength() As cabLength
            Get
                Return truckCabLength
            End Get
            Set(ByVal value As cabLength)
                If value >= 0 And value <= 2 Then
                    truckCabLength = value
                End If
            End Set
        End Property
        'Gives the information about the truck
        Public Function getTruckInfo() As String
            Return "Car Name: " & CarName & Environment.NewLine & "Car Color: " & Color & Environment.NewLine & "Cab Size: " & truckCabLength & Environment.NewLine & "Bed Length: " & truckBedLength & Environment.NewLine & "Number of Doors: " & NumberOfDoors & Environment.NewLine & "Car Speed: " & Speed
        End Function
    End Class

    'Cab length enumeration
    Enum cabLength As Integer
        SingleCab = 0
        ExtendedCab = 1
        CrewMax = 2
    End Enum
    'BedLength Enumeration: short medium long
    Enum bedLength As Integer
        ShortBed = 0
        MediumBed = 1
        LongBed = 2
    End Enum
End Namespace
