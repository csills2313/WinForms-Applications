﻿Public Class Form1

    Private defaultCar As New AllCars.Car
    Private defaultSportsCar As New AllCars.SportsCar
    Private cars As New ArrayList
    Private selectedCar As AllCars.Car

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        comboCarTypes.SelectedIndex = 0
        defaultCar.CarName = "Honda CR-V"
        defaultSportsCar.CarName = "Mustang GT"
        cars.Add(defaultCar)
        cars.Add(defaultSportsCar)
        addAllCars()
    End Sub
    'Subs created by me
    Private Sub addAllCars()
        For Each car As AllCars.Car In cars
            listCars.Items.Add(car.CarName)
        Next
    End Sub
    Private Sub showCarInfo(ByVal argCar As AllCars.Car)
        MessageBox.Show(argCar.ToString(), "Info")
    End Sub

    Private Sub listCars_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles listCars.SelectedIndexChanged
        If listCars.SelectedIndex <> -1 Then
            selectedCar = cars(listCars.SelectedIndex)
        End If
    End Sub

    'Button Click Events
    Private Sub btnSetName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetName.Click
        cars(listCars.SelectedIndex).CarName = InputBox("Please enter the new name of your car." & Environment.NewLine & "Old Name: " & cars(listCars.SelectedIndex).CarName, "Name")
        listCars.Items(listCars.SelectedIndex) = cars(listCars.SelectedIndex).CarName
    End Sub
    Private Sub btnSetColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetColor.Click
        cars(listCars.SelectedIndex).Color = InputBox("Please enter the new color of your car." & Environment.NewLine & "Old Color: " & cars(listCars.SelectedIndex).Color, "Color")
    End Sub
    Private Sub btnShowCarInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCarInfo.Click
        showCarInfo(cars(listCars.SelectedIndex))
    End Sub
    Private Sub btnSetDoors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetDoors.Click
        cars(listCars.SelectedIndex).NumberOfDoors = CType(InputBox("Please enter the number of doors" & Environment.NewLine & "Old Number: " & cars(listCars.SelectedIndex).NumberOfDoors, "Doors"), Integer)
    End Sub
    Private Sub btnAccelerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAccelerate.Click
        cars(listCars.SelectedIndex).Accelerate(CType(InputBox("Please enter the speed in mph to accelerate", "Speed"), Integer))
    End Sub
    Private Sub btnGetPowerWeight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetPowerWeight.Click
        MessageBox.Show(Convert.ToString(cars(listCars.SelectedIndex).getPowerToWeightRatio()), "P/W Ratio")
    End Sub
    Private Sub btnCreateCar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateCar.Click
        CreateCar()
    End Sub

    'Testing stuff
    Private Sub CreateCar()
        Dim addNewCar As New NewCar
        addNewCar.vehicleType = comboCarTypes.SelectedItem
        addNewCar.ShowDialog()
        Dim newCar1
        If addNewCar.boolCreate = True Then
            If comboCarTypes.SelectedIndex = 0 Then
                newCar1 = New AllCars.Car
            ElseIf comboCarTypes.SelectedIndex = 1 Then
                newCar1 = New AllCars.TruckCar
            ElseIf comboCarTypes.SelectedIndex = 2 Then
                newCar1 = New AllCars.SportsCar
            End If
            Using newCar1
                With newCar1
                    .CarName = addNewCar.carName
                    .Color = addNewCar.carColor
                    .HorsePower = addNewCar.carHorse
                    .NumberOfDoors = addNewCar.carDoors
                End With
                cars.Add(newCar1)
                listCars.Items.Add(newCar1.CarName)
            End Using
        End If
    End Sub
End Class
