﻿Public Class NewCar
    Public carName As String
    Public carColor As String
    Public carDoors As Integer
    Public carHorse As String
    Public boolCreate As Boolean = False
    Public vehicleType As String


    Private Sub txtCarName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCarName.TextChanged
        carName = txtCarName.Text
    End Sub
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        carColor = TextBox1.Text
    End Sub
    Private Sub numerDoors_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles numerDoors.ValueChanged
        carDoors = numerDoors.Value
    End Sub
    Private Sub txtHorse_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtHorse.TextChanged
        carHorse = txtHorse.Text
    End Sub
    Private Sub btnAddCar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddCar.Click
        boolCreate = True
        Me.Close()
    End Sub
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub NewCar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblName.Text = "Name Of " & vehicleType
        lblColor.Text = "Color Of " & vehicleType
    End Sub
End Class