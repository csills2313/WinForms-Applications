﻿Public Class Form1
    Private FTPDownloader As New Utilities.FTP.FTPclient
    Private isFolder As Boolean = False
    Private isUpdating As Boolean = False
    Private checking As Boolean = False

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnChangeDirectory.Enabled = False
        FTPDownloader.Hostname = txtFTPserver.Text.Trim
        FTPDownloader.Username = txtFTPuser.Text
        FTPDownloader.Password = txtFTPpass.Text
    End Sub

    Private Sub btnHomeDirectory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHomeDirectory.Click
        FTPDownloader.CurrentDirectory = "/"
        RefreshList()
        updateDirectoryLabel()
    End Sub

    'REALLY IMPORTANT: ADDS ITEMS TO LISTBOX
    Private Sub RefreshList()
        ListFTPFiles.Items.Clear()
        Try
            For Each file In FTPDownloader.ListDirectoryDetail()
                ListFTPFiles.Items.Add(file.Filename)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnDownload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDownload.Click
        If ListFTPFiles.SelectedIndex <> -1 Then
            If MessageBox.Show("Are you sure you want to download " & ListFTPFiles.SelectedItem, "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = DialogResult.OK Then
                FTPDownloader.Download(ListFTPFiles.SelectedItem, My.Computer.FileSystem.SpecialDirectories.MyDocuments + "\" + ListFTPFiles.SelectedItem, True)
            End If
        Else
            MessageBox.Show("Please select a file!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub ListFTPFiles_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListFTPFiles.SelectedIndexChanged
        Dim folderName As String = ListFTPFiles.SelectedItem
        If Not folderName.Contains(".") Then
            isFolder = True
            btnChangeDirectory.Enabled = True
        Else
            isFolder = False
            btnChangeDirectory.Enabled = False
        End If
    End Sub

    Private Sub btnChangeDirectory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChangeDirectory.Click
        FTPDownloader.CurrentDirectory += ListFTPFiles.SelectedItem + "/"
        RefreshList()
        updateDirectoryLabel()
    End Sub

    Private Sub updateDirectoryLabel()
        lblDirectory.Text = "Current Directory: " & FTPDownloader.CurrentDirectory
    End Sub

    Private Sub btnUpdateSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateSettings.Click
        isUpdating = Not isUpdating
        If isUpdating Then
            UpdatingServer(True)
            btnUpdateSettings.Text = "Save Server Settings"
        ElseIf Not isUpdating Then
            UpdatingServer(False)
            btnUpdateSettings.Text = "Update Server"
            FTPDownloader.Username = txtFTPuser.Text
            FTPDownloader.Password = txtFTPpass.Text
            FTPDownloader.Hostname = txtFTPserver.Text.Trim
        End If
    End Sub

    Private Sub UpdatingServer(ByVal isUp As Boolean)
        txtFTPpass.Enabled = isUp
        txtFTPserver.Enabled = isUp
        txtFTPuser.Enabled = isUp
    End Sub

    Private Sub btnUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpload.Click
        Dim pathName As String
        Dim fileName As String
        OpenFileToUpload.Title = "Please Select A File To Upload"
        If OpenFileToUpload.ShowDialog() = Windows.Forms.DialogResult.OK Then
            pathName = OpenFileToUpload.FileName
            fileName = pathName.Substring(pathName.LastIndexOf("\") + 1)
        End If
        Try
            FTPDownloader.Upload(pathName, fileName)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        RefreshList()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim file As String = ListFTPFiles.SelectedItem
        If ListFTPFiles.SelectedIndex <> -1 And file.Contains(".") Then
            FTPDownloader.FtpDelete(ListFTPFiles.SelectedItem)
        Else
            MessageBox.Show("Please select a file!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        RefreshList()
    End Sub

    Private Sub btnCheckForNewFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckForNewFiles.Click
        RefreshList()
    End Sub

    Private Sub btnClearList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearList.Click
        ListFTPFiles.Items.Clear()
    End Sub

    Private Sub btnStartCheckTimer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStartCheckTimer.Click
        checking = Not checking
        If checking Then
            btnStartCheckTimer.Text = "Stop Checking For New Files"
            timerChecking.Start()
        ElseIf Not checking Then
            btnStartCheckTimer.Text = "Start Checking For New Files"
            timerChecking.Stop()
        End If
    End Sub

    Private Sub timerChecking_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timerChecking.Tick
        For Each file In FTPDownloader.ListDirectoryDetail()
            If (Not ListFTPFiles.Items.Contains(file.Filename)) Then
                ListFTPFiles.Items.Add(file.Filename)
                NotifyNewFile.ShowBalloonTip(10000, "New File", "The new file found is: " & file.Filename, ToolTipIcon.Info)
            End If
        Next
    End Sub
End Class
