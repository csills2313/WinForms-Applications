﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblServer = New System.Windows.Forms.Label()
        Me.txtFTPserver = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.txtFTPpass = New System.Windows.Forms.TextBox()
        Me.txtFTPuser = New System.Windows.Forms.TextBox()
        Me.btnHomeDirectory = New System.Windows.Forms.Button()
        Me.btnChangeDirectory = New System.Windows.Forms.Button()
        Me.btnDownload = New System.Windows.Forms.Button()
        Me.btnUpdateSettings = New System.Windows.Forms.Button()
        Me.btnUpload = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnStartCheckTimer = New System.Windows.Forms.Button()
        Me.btnClearList = New System.Windows.Forms.Button()
        Me.btnCheckForNewFiles = New System.Windows.Forms.Button()
        Me.lblFile = New System.Windows.Forms.Label()
        Me.ListFTPFiles = New System.Windows.Forms.ListBox()
        Me.lblDirectory = New System.Windows.Forms.Label()
        Me.OpenFileToUpload = New System.Windows.Forms.OpenFileDialog()
        Me.timerChecking = New System.Windows.Forms.Timer(Me.components)
        Me.NotifyNewFile = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.SuspendLayout()
        '
        'lblServer
        '
        Me.lblServer.AutoSize = True
        Me.lblServer.Location = New System.Drawing.Point(424, 19)
        Me.lblServer.Name = "lblServer"
        Me.lblServer.Size = New System.Drawing.Size(41, 13)
        Me.lblServer.TabIndex = 13
        Me.lblServer.Text = "Server:"
        '
        'txtFTPserver
        '
        Me.txtFTPserver.Enabled = False
        Me.txtFTPserver.Location = New System.Drawing.Point(426, 35)
        Me.txtFTPserver.Name = "txtFTPserver"
        Me.txtFTPserver.Size = New System.Drawing.Size(214, 20)
        Me.txtFTPserver.TabIndex = 12
        Me.txtFTPserver.Text = "ftp://192.168.1.11"
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(426, 99)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(56, 13)
        Me.lblPassword.TabIndex = 11
        Me.lblPassword.Text = "Password:"
        '
        'lblUserName
        '
        Me.lblUserName.AutoSize = True
        Me.lblUserName.Location = New System.Drawing.Point(424, 58)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(58, 13)
        Me.lblUserName.TabIndex = 10
        Me.lblUserName.Text = "Username:"
        '
        'txtFTPpass
        '
        Me.txtFTPpass.Enabled = False
        Me.txtFTPpass.Location = New System.Drawing.Point(426, 115)
        Me.txtFTPpass.Name = "txtFTPpass"
        Me.txtFTPpass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtFTPpass.Size = New System.Drawing.Size(214, 20)
        Me.txtFTPpass.TabIndex = 9
        '
        'txtFTPuser
        '
        Me.txtFTPuser.Enabled = False
        Me.txtFTPuser.Location = New System.Drawing.Point(426, 74)
        Me.txtFTPuser.Name = "txtFTPuser"
        Me.txtFTPuser.Size = New System.Drawing.Size(214, 20)
        Me.txtFTPuser.TabIndex = 8
        Me.txtFTPuser.Text = "Tutorials"
        '
        'btnHomeDirectory
        '
        Me.btnHomeDirectory.Location = New System.Drawing.Point(428, 199)
        Me.btnHomeDirectory.Name = "btnHomeDirectory"
        Me.btnHomeDirectory.Size = New System.Drawing.Size(215, 23)
        Me.btnHomeDirectory.TabIndex = 24
        Me.btnHomeDirectory.Text = "Home Directory"
        Me.btnHomeDirectory.UseVisualStyleBackColor = True
        '
        'btnChangeDirectory
        '
        Me.btnChangeDirectory.Location = New System.Drawing.Point(427, 170)
        Me.btnChangeDirectory.Name = "btnChangeDirectory"
        Me.btnChangeDirectory.Size = New System.Drawing.Size(214, 23)
        Me.btnChangeDirectory.TabIndex = 23
        Me.btnChangeDirectory.Text = "Open Folder"
        Me.btnChangeDirectory.UseVisualStyleBackColor = True
        '
        'btnDownload
        '
        Me.btnDownload.Location = New System.Drawing.Point(428, 228)
        Me.btnDownload.Name = "btnDownload"
        Me.btnDownload.Size = New System.Drawing.Size(214, 23)
        Me.btnDownload.TabIndex = 22
        Me.btnDownload.Text = "Download"
        Me.btnDownload.UseVisualStyleBackColor = True
        '
        'btnUpdateSettings
        '
        Me.btnUpdateSettings.Location = New System.Drawing.Point(427, 141)
        Me.btnUpdateSettings.Name = "btnUpdateSettings"
        Me.btnUpdateSettings.Size = New System.Drawing.Size(214, 23)
        Me.btnUpdateSettings.TabIndex = 21
        Me.btnUpdateSettings.Text = "Update Server"
        Me.btnUpdateSettings.UseVisualStyleBackColor = True
        '
        'btnUpload
        '
        Me.btnUpload.Location = New System.Drawing.Point(429, 260)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(215, 23)
        Me.btnUpload.TabIndex = 26
        Me.btnUpload.Text = "Upload"
        Me.btnUpload.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(429, 289)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(215, 23)
        Me.btnDelete.TabIndex = 25
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnStartCheckTimer
        '
        Me.btnStartCheckTimer.Location = New System.Drawing.Point(12, 320)
        Me.btnStartCheckTimer.Name = "btnStartCheckTimer"
        Me.btnStartCheckTimer.Size = New System.Drawing.Size(628, 23)
        Me.btnStartCheckTimer.TabIndex = 29
        Me.btnStartCheckTimer.Text = "Start Checking For New Files"
        Me.btnStartCheckTimer.UseVisualStyleBackColor = True
        '
        'btnClearList
        '
        Me.btnClearList.Location = New System.Drawing.Point(212, 290)
        Me.btnClearList.Name = "btnClearList"
        Me.btnClearList.Size = New System.Drawing.Size(200, 23)
        Me.btnClearList.TabIndex = 28
        Me.btnClearList.Text = "Clear"
        Me.btnClearList.UseVisualStyleBackColor = True
        '
        'btnCheckForNewFiles
        '
        Me.btnCheckForNewFiles.Location = New System.Drawing.Point(12, 290)
        Me.btnCheckForNewFiles.Name = "btnCheckForNewFiles"
        Me.btnCheckForNewFiles.Size = New System.Drawing.Size(194, 23)
        Me.btnCheckForNewFiles.TabIndex = 27
        Me.btnCheckForNewFiles.Text = "Load Files"
        Me.btnCheckForNewFiles.UseVisualStyleBackColor = True
        '
        'lblFile
        '
        Me.lblFile.AutoSize = True
        Me.lblFile.Location = New System.Drawing.Point(15, 16)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.Size = New System.Drawing.Size(38, 13)
        Me.lblFile.TabIndex = 31
        Me.lblFile.Text = "Name:"
        '
        'ListFTPFiles
        '
        Me.ListFTPFiles.FormattingEnabled = True
        Me.ListFTPFiles.Location = New System.Drawing.Point(15, 35)
        Me.ListFTPFiles.Name = "ListFTPFiles"
        Me.ListFTPFiles.Size = New System.Drawing.Size(397, 225)
        Me.ListFTPFiles.TabIndex = 30
        '
        'lblDirectory
        '
        Me.lblDirectory.AutoSize = True
        Me.lblDirectory.Location = New System.Drawing.Point(12, 270)
        Me.lblDirectory.Name = "lblDirectory"
        Me.lblDirectory.Size = New System.Drawing.Size(89, 13)
        Me.lblDirectory.TabIndex = 32
        Me.lblDirectory.Text = "Current Directory:"
        '
        'OpenFileToUpload
        '
        Me.OpenFileToUpload.FileName = "OpenFileToUpload"
        '
        'timerChecking
        '
        '
        'NotifyNewFile
        '
        Me.NotifyNewFile.Icon = CType(resources.GetObject("NotifyNewFile.Icon"), System.Drawing.Icon)
        Me.NotifyNewFile.Text = "NotifyIcon1"
        Me.NotifyNewFile.Visible = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(655, 355)
        Me.Controls.Add(Me.lblDirectory)
        Me.Controls.Add(Me.lblFile)
        Me.Controls.Add(Me.ListFTPFiles)
        Me.Controls.Add(Me.btnStartCheckTimer)
        Me.Controls.Add(Me.btnClearList)
        Me.Controls.Add(Me.btnCheckForNewFiles)
        Me.Controls.Add(Me.btnUpload)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnHomeDirectory)
        Me.Controls.Add(Me.btnChangeDirectory)
        Me.Controls.Add(Me.btnDownload)
        Me.Controls.Add(Me.btnUpdateSettings)
        Me.Controls.Add(Me.lblServer)
        Me.Controls.Add(Me.txtFTPserver)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblUserName)
        Me.Controls.Add(Me.txtFTPpass)
        Me.Controls.Add(Me.txtFTPuser)
        Me.Name = "Form1"
        Me.Text = "FTP Downloader"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblServer As System.Windows.Forms.Label
    Friend WithEvents txtFTPserver As System.Windows.Forms.TextBox
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents lblUserName As System.Windows.Forms.Label
    Friend WithEvents txtFTPpass As System.Windows.Forms.TextBox
    Friend WithEvents txtFTPuser As System.Windows.Forms.TextBox
    Friend WithEvents btnHomeDirectory As System.Windows.Forms.Button
    Friend WithEvents btnChangeDirectory As System.Windows.Forms.Button
    Friend WithEvents btnDownload As System.Windows.Forms.Button
    Friend WithEvents btnUpdateSettings As System.Windows.Forms.Button
    Friend WithEvents btnUpload As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnStartCheckTimer As System.Windows.Forms.Button
    Friend WithEvents btnClearList As System.Windows.Forms.Button
    Friend WithEvents btnCheckForNewFiles As System.Windows.Forms.Button
    Friend WithEvents lblFile As System.Windows.Forms.Label
    Friend WithEvents ListFTPFiles As System.Windows.Forms.ListBox
    Friend WithEvents lblDirectory As System.Windows.Forms.Label
    Friend WithEvents OpenFileToUpload As System.Windows.Forms.OpenFileDialog
    Friend WithEvents timerChecking As System.Windows.Forms.Timer
    Friend WithEvents NotifyNewFile As System.Windows.Forms.NotifyIcon

End Class
