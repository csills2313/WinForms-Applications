﻿Public Class Viewer

    Private Sub Viewer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lnkURL.Text = "Visit " & "OnliveGamer"
        lnkURL.Links.Clear()
        lnkURL.Links.Add(6, 11, "http://www.youtube.com/onlivegamer")
        LoadFavorites()
    End Sub

    Private Sub lstFavorites_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstFavorites.Click
        lnkURL.Text = "Visit " & lstFavorites.SelectedItems.Item(0).Text
        lnkURL.Links.Clear()
        lnkURL.Links.Add(6, lstFavorites.SelectedItems.Item(0).Text.Length, lstFavorites.SelectedItems.Item(0).SubItems(1).Text)
    End Sub

    Private Sub lnkURL_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkURL.LinkClicked
        Process.Start(e.Link.LinkData)
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        LoadFavorites()
    End Sub

    Private Sub LoadFavorites()
        lstFavorites.Items.Clear()
        Dim objMenu As New ContextMenu()
        Try
            Using objFavorites As New Favorites
                objFavorites.ScanFavorites()
                For Each objWebFavorite As WebFavorite In objFavorites.FavoritesCollection
                    Dim objListViewItem As New ListViewItem
                    Dim objItem As New WebFavoriteMenuItem(objWebFavorite)
                    objMenu.MenuItems.Add(objItem)
                    objListViewItem.Text = objWebFavorite.Name
                    objListViewItem.SubItems.Add(objWebFavorite.URL)
                    lstFavorites.Items.Add(objListViewItem)
                Next
            End Using
            objMenu.MenuItems.Add("-")
            objMenu.MenuItems.Add(New ExitMenuItem())
            icnFavorites.ContextMenu = objMenu
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub icnFavorites_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub Viewer_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Me.WindowState = FormWindowState.Minimized Then
            Me.Hide()
        End If
    End Sub

    Private Sub icnFavorites_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles icnFavorites.MouseDoubleClick
        Me.Show()
        Me.WindowState = FormWindowState.Normal
    End Sub
End Class
