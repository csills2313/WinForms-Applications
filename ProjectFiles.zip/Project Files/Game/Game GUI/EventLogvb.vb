﻿Public Class EventLogvb

    Private Sub EventLogvb_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ListEvents.Items.Add("Event Logger Has Successfully Loaded")
        ListEvents.Items.Add("------------------------------------")
    End Sub

    Public Sub AddEvent(ByVal strEvent As String)
        ListEvents.Items.Add(strEvent)
    End Sub
End Class