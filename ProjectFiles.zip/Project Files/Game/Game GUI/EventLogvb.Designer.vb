﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EventLogvb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListEvents = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'ListEvents
        '
        Me.ListEvents.BackColor = System.Drawing.Color.Black
        Me.ListEvents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListEvents.ForeColor = System.Drawing.Color.Lime
        Me.ListEvents.FormattingEnabled = True
        Me.ListEvents.Location = New System.Drawing.Point(0, 0)
        Me.ListEvents.Name = "ListEvents"
        Me.ListEvents.Size = New System.Drawing.Size(441, 193)
        Me.ListEvents.TabIndex = 0
        '
        'EventLogvb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(441, 193)
        Me.Controls.Add(Me.ListEvents)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "EventLogvb"
        Me.Text = "EventLogvb"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ListEvents As System.Windows.Forms.ListBox
End Class
