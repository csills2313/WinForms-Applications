﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.picturePopeye = New System.Windows.Forms.PictureBox()
        Me.pictureEnemy = New System.Windows.Forms.PictureBox()
        Me.btnAttack = New System.Windows.Forms.Button()
        Me.ProgressBarPopeye = New System.Windows.Forms.ProgressBar()
        Me.ProgressBarEnemy = New System.Windows.Forms.ProgressBar()
        Me.btnSpawn = New System.Windows.Forms.Button()
        Me.lblSpinachLeft = New System.Windows.Forms.Label()
        Me.timerDelay = New System.Windows.Forms.Timer(Me.components)
        Me.CheckSpinach = New System.Windows.Forms.CheckBox()
        Me.lblPopHealth = New System.Windows.Forms.Label()
        Me.lblEnemyHealth = New System.Windows.Forms.Label()
        Me.btnHideAndShow = New System.Windows.Forms.Button()
        CType(Me.picturePopeye, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureEnemy, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picturePopeye
        '
        Me.picturePopeye.Image = CType(resources.GetObject("picturePopeye.Image"), System.Drawing.Image)
        Me.picturePopeye.Location = New System.Drawing.Point(22, 53)
        Me.picturePopeye.Name = "picturePopeye"
        Me.picturePopeye.Size = New System.Drawing.Size(129, 176)
        Me.picturePopeye.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picturePopeye.TabIndex = 0
        Me.picturePopeye.TabStop = False
        '
        'pictureEnemy
        '
        Me.pictureEnemy.Image = CType(resources.GetObject("pictureEnemy.Image"), System.Drawing.Image)
        Me.pictureEnemy.Location = New System.Drawing.Point(258, 53)
        Me.pictureEnemy.Name = "pictureEnemy"
        Me.pictureEnemy.Size = New System.Drawing.Size(152, 176)
        Me.pictureEnemy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureEnemy.TabIndex = 1
        Me.pictureEnemy.TabStop = False
        '
        'btnAttack
        '
        Me.btnAttack.Location = New System.Drawing.Point(12, 14)
        Me.btnAttack.Name = "btnAttack"
        Me.btnAttack.Size = New System.Drawing.Size(93, 23)
        Me.btnAttack.TabIndex = 2
        Me.btnAttack.Text = "Attack"
        Me.btnAttack.UseVisualStyleBackColor = True
        '
        'ProgressBarPopeye
        '
        Me.ProgressBarPopeye.Location = New System.Drawing.Point(11, 240)
        Me.ProgressBarPopeye.Maximum = 250
        Me.ProgressBarPopeye.Name = "ProgressBarPopeye"
        Me.ProgressBarPopeye.Size = New System.Drawing.Size(151, 23)
        Me.ProgressBarPopeye.TabIndex = 3
        '
        'ProgressBarEnemy
        '
        Me.ProgressBarEnemy.ForeColor = System.Drawing.Color.Red
        Me.ProgressBarEnemy.Location = New System.Drawing.Point(259, 240)
        Me.ProgressBarEnemy.Name = "ProgressBarEnemy"
        Me.ProgressBarEnemy.Size = New System.Drawing.Size(151, 23)
        Me.ProgressBarEnemy.TabIndex = 4
        '
        'btnSpawn
        '
        Me.btnSpawn.Location = New System.Drawing.Point(259, 14)
        Me.btnSpawn.Name = "btnSpawn"
        Me.btnSpawn.Size = New System.Drawing.Size(152, 23)
        Me.btnSpawn.TabIndex = 5
        Me.btnSpawn.Text = "Spawn Enemy"
        Me.btnSpawn.UseVisualStyleBackColor = True
        '
        'lblSpinachLeft
        '
        Me.lblSpinachLeft.AutoSize = True
        Me.lblSpinachLeft.Location = New System.Drawing.Point(108, 37)
        Me.lblSpinachLeft.Name = "lblSpinachLeft"
        Me.lblSpinachLeft.Size = New System.Drawing.Size(79, 13)
        Me.lblSpinachLeft.TabIndex = 7
        Me.lblSpinachLeft.Text = "Spinach Left: 3"
        '
        'timerDelay
        '
        Me.timerDelay.Interval = 1000
        '
        'CheckSpinach
        '
        Me.CheckSpinach.AutoSize = True
        Me.CheckSpinach.Location = New System.Drawing.Point(111, 17)
        Me.CheckSpinach.Name = "CheckSpinach"
        Me.CheckSpinach.Size = New System.Drawing.Size(87, 17)
        Me.CheckSpinach.TabIndex = 8
        Me.CheckSpinach.Text = "Use Spinach"
        Me.CheckSpinach.UseVisualStyleBackColor = True
        '
        'lblPopHealth
        '
        Me.lblPopHealth.AutoSize = True
        Me.lblPopHealth.Location = New System.Drawing.Point(9, 268)
        Me.lblPopHealth.Name = "lblPopHealth"
        Me.lblPopHealth.Size = New System.Drawing.Size(41, 13)
        Me.lblPopHealth.TabIndex = 9
        Me.lblPopHealth.Text = "Health:"
        '
        'lblEnemyHealth
        '
        Me.lblEnemyHealth.AutoSize = True
        Me.lblEnemyHealth.Location = New System.Drawing.Point(256, 268)
        Me.lblEnemyHealth.Name = "lblEnemyHealth"
        Me.lblEnemyHealth.Size = New System.Drawing.Size(41, 13)
        Me.lblEnemyHealth.TabIndex = 10
        Me.lblEnemyHealth.Text = "Health:"
        '
        'btnHideAndShow
        '
        Me.btnHideAndShow.Location = New System.Drawing.Point(11, 284)
        Me.btnHideAndShow.Name = "btnHideAndShow"
        Me.btnHideAndShow.Size = New System.Drawing.Size(418, 23)
        Me.btnHideAndShow.TabIndex = 11
        Me.btnHideAndShow.Text = "Hide Log"
        Me.btnHideAndShow.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(441, 318)
        Me.Controls.Add(Me.btnHideAndShow)
        Me.Controls.Add(Me.lblEnemyHealth)
        Me.Controls.Add(Me.lblPopHealth)
        Me.Controls.Add(Me.CheckSpinach)
        Me.Controls.Add(Me.lblSpinachLeft)
        Me.Controls.Add(Me.btnSpawn)
        Me.Controls.Add(Me.ProgressBarEnemy)
        Me.Controls.Add(Me.ProgressBarPopeye)
        Me.Controls.Add(Me.btnAttack)
        Me.Controls.Add(Me.pictureEnemy)
        Me.Controls.Add(Me.picturePopeye)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.picturePopeye, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureEnemy, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picturePopeye As System.Windows.Forms.PictureBox
    Friend WithEvents pictureEnemy As System.Windows.Forms.PictureBox
    Friend WithEvents btnAttack As System.Windows.Forms.Button
    Friend WithEvents ProgressBarPopeye As System.Windows.Forms.ProgressBar
    Friend WithEvents ProgressBarEnemy As System.Windows.Forms.ProgressBar
    Friend WithEvents btnSpawn As System.Windows.Forms.Button
    Friend WithEvents lblSpinachLeft As System.Windows.Forms.Label
    Friend WithEvents timerDelay As System.Windows.Forms.Timer
    Friend WithEvents CheckSpinach As System.Windows.Forms.CheckBox
    Friend WithEvents lblPopHealth As System.Windows.Forms.Label
    Friend WithEvents lblEnemyHealth As System.Windows.Forms.Label
    Friend WithEvents btnHideAndShow As System.Windows.Forms.Button

End Class
