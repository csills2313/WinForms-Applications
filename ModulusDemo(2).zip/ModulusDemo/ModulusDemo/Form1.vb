﻿Public Class FormMain
    Private Sub ButtonGenerate_Click(sender As System.Object, e As System.EventArgs) Handles ButtonGenerate.Click
        Dim RandomMax, Result As Integer
        If Not String.IsNullOrEmpty(TextBoxMax.Text) Then 'Check to make sure that the text box is not empty
            Try 'Handle improper input exceptions caused by letters and other non-numeric characters
                RandomMax = Convert.ToInt32(TextBoxMax.Text)
                Result = Convert.ToInt32((DateAndTime.Timer * 100) Mod RandomMax) 'Multiply by 100 to make the max base value larger
                TextBoxBaseValue.Text = (DateAndTime.Timer * 100).ToString()
                TextBoxResult.Text = Result.ToString()
            Catch ex As Exception
                MessageBox.Show("Input error. Please only use numeric characters 0 through 9.")
            End Try
        Else
            MessageBox.Show("Please enter a maximum value")
        End If
    End Sub

    Private Sub ButtonClose_Click(sender As System.Object, e As System.EventArgs) Handles ButtonClose.Click
        Me.Close()
    End Sub
End Class
