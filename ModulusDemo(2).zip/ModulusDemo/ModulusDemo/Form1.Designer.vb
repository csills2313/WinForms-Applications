﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelMax = New System.Windows.Forms.Label()
        Me.TextBoxMax = New System.Windows.Forms.TextBox()
        Me.ButtonGenerate = New System.Windows.Forms.Button()
        Me.TextBoxResult = New System.Windows.Forms.TextBox()
        Me.ButtonClose = New System.Windows.Forms.Button()
        Me.LabelBaseValue = New System.Windows.Forms.Label()
        Me.LabelResult = New System.Windows.Forms.Label()
        Me.TextBoxBaseValue = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'LabelMax
        '
        Me.LabelMax.AutoSize = True
        Me.LabelMax.Location = New System.Drawing.Point(12, 15)
        Me.LabelMax.Name = "LabelMax"
        Me.LabelMax.Size = New System.Drawing.Size(128, 13)
        Me.LabelMax.TabIndex = 0
        Me.LabelMax.Text = "Set the maximum value to"
        '
        'TextBoxMax
        '
        Me.TextBoxMax.Location = New System.Drawing.Point(146, 12)
        Me.TextBoxMax.Name = "TextBoxMax"
        Me.TextBoxMax.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxMax.TabIndex = 1
        '
        'ButtonGenerate
        '
        Me.ButtonGenerate.Location = New System.Drawing.Point(15, 110)
        Me.ButtonGenerate.Name = "ButtonGenerate"
        Me.ButtonGenerate.Size = New System.Drawing.Size(75, 23)
        Me.ButtonGenerate.TabIndex = 2
        Me.ButtonGenerate.Text = "Generate"
        Me.ButtonGenerate.UseVisualStyleBackColor = True
        '
        'TextBoxResult
        '
        Me.TextBoxResult.Location = New System.Drawing.Point(146, 65)
        Me.TextBoxResult.Name = "TextBoxResult"
        Me.TextBoxResult.ReadOnly = True
        Me.TextBoxResult.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxResult.TabIndex = 7
        '
        'ButtonClose
        '
        Me.ButtonClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonClose.Location = New System.Drawing.Point(96, 110)
        Me.ButtonClose.Name = "ButtonClose"
        Me.ButtonClose.Size = New System.Drawing.Size(75, 23)
        Me.ButtonClose.TabIndex = 3
        Me.ButtonClose.Text = "Close"
        Me.ButtonClose.UseVisualStyleBackColor = True
        '
        'LabelBaseValue
        '
        Me.LabelBaseValue.AutoSize = True
        Me.LabelBaseValue.Location = New System.Drawing.Point(12, 42)
        Me.LabelBaseValue.Name = "LabelBaseValue"
        Me.LabelBaseValue.Size = New System.Drawing.Size(61, 13)
        Me.LabelBaseValue.TabIndex = 4
        Me.LabelBaseValue.Text = "Base Value"
        '
        'LabelResult
        '
        Me.LabelResult.AutoSize = True
        Me.LabelResult.Location = New System.Drawing.Point(12, 68)
        Me.LabelResult.Name = "LabelResult"
        Me.LabelResult.Size = New System.Drawing.Size(37, 13)
        Me.LabelResult.TabIndex = 6
        Me.LabelResult.Text = "Result"
        '
        'TextBoxBaseValue
        '
        Me.TextBoxBaseValue.Location = New System.Drawing.Point(146, 39)
        Me.TextBoxBaseValue.Name = "TextBoxBaseValue"
        Me.TextBoxBaseValue.ReadOnly = True
        Me.TextBoxBaseValue.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxBaseValue.TabIndex = 5
        '
        'FormMain
        '
        Me.AcceptButton = Me.ButtonGenerate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.ButtonClose
        Me.ClientSize = New System.Drawing.Size(269, 156)
        Me.Controls.Add(Me.TextBoxBaseValue)
        Me.Controls.Add(Me.LabelResult)
        Me.Controls.Add(Me.LabelBaseValue)
        Me.Controls.Add(Me.ButtonClose)
        Me.Controls.Add(Me.TextBoxResult)
        Me.Controls.Add(Me.ButtonGenerate)
        Me.Controls.Add(Me.TextBoxMax)
        Me.Controls.Add(Me.LabelMax)
        Me.Name = "FormMain"
        Me.Text = "Modulus Demo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LabelMax As System.Windows.Forms.Label
    Friend WithEvents TextBoxMax As System.Windows.Forms.TextBox
    Friend WithEvents ButtonGenerate As System.Windows.Forms.Button
    Friend WithEvents TextBoxResult As System.Windows.Forms.TextBox
    Friend WithEvents ButtonClose As System.Windows.Forms.Button
    Friend WithEvents LabelBaseValue As System.Windows.Forms.Label
    Friend WithEvents LabelResult As System.Windows.Forms.Label
    Friend WithEvents TextBoxBaseValue As System.Windows.Forms.TextBox

End Class
